package com.example.hudhealthbar.client;

import com.example.hudhealthbar.HudHealthBarMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

public class ClientSetup {
    public static final KeyMapping OPEN_KEY = new KeyMapping(
            "key.hudhealthbar.open_menu",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_H,
            "key.categories.hudhealthbar");

    @Mod.EventBusSubscriber(modid = HudHealthBarMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class Keys {
        @SubscribeEvent
        public static void registerKeys(RegisterKeyMappingsEvent event) {
            event.register(OPEN_KEY);
        }
    }

    @Mod.EventBusSubscriber(modid = HudHealthBarMod.MODID, value = Dist.CLIENT)
    public static class Ticks {
        @SubscribeEvent
        public static void onTick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            while (OPEN_KEY.consumeClick()) {
                if (mc.screen == null && mc.player != null) mc.setScreen(new HealthBarScreen());
            }
        }
    }
}
