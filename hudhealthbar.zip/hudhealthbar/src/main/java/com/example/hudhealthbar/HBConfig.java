package com.example.hudhealthbar;

import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Simple properties-file config stored in config/hudhealthbar.properties */
public class HBConfig {
    public static boolean healthBar = true;
    public static boolean hbText = true;
    public static boolean hbHideFull = false;
    public static boolean hbHideVanilla = true;
    public static int hbWidth = 81;
    public static int hbHeight = 10;
    /** Horizontal shift from the screen centre (pixels, negative = left). */
    public static int hbX = -50;
    /** Distance of the bar's bottom edge from the bottom of the screen (pixels). */
    public static int hbY = 30;

    private static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve("hudhealthbar.properties");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) {
            save();
            return;
        }
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(f)) {
            p.load(r);
        } catch (IOException e) {
            return;
        }
        healthBar = bool(p, "healthBar", healthBar);
        hbText = bool(p, "hbText", hbText);
        hbHideFull = bool(p, "hbHideFull", hbHideFull);
        hbHideVanilla = bool(p, "hbHideVanilla", hbHideVanilla);
        hbWidth = (int) num(p, "hbWidth", hbWidth, 40, 400);
        hbHeight = (int) num(p, "hbHeight", hbHeight, 8, 30);
        hbX = (int) num(p, "hbX", hbX, -400, 400);
        hbY = (int) num(p, "hbY", hbY, 4, 400);
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("healthBar", String.valueOf(healthBar));
        p.setProperty("hbText", String.valueOf(hbText));
        p.setProperty("hbHideFull", String.valueOf(hbHideFull));
        p.setProperty("hbHideVanilla", String.valueOf(hbHideVanilla));
        p.setProperty("hbWidth", String.valueOf(hbWidth));
        p.setProperty("hbHeight", String.valueOf(hbHeight));
        p.setProperty("hbX", String.valueOf(hbX));
        p.setProperty("hbY", String.valueOf(hbY));
        try (Writer w = Files.newBufferedWriter(file())) {
            p.store(w, "HUD Health Bar client config");
        } catch (IOException ignored) {
        }
    }

    private static boolean bool(Properties p, String k, boolean def) {
        String v = p.getProperty(k);
        return v == null ? def : Boolean.parseBoolean(v);
    }

    private static float num(Properties p, String k, float def, float min, float max) {
        try {
            float v = Float.parseFloat(p.getProperty(k, String.valueOf(def)));
            return Math.max(min, Math.min(max, v));
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
