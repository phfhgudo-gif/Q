package com.example.hudhealthbar;

import net.minecraftforge.fml.common.Mod;

/** Client-side only: a flat on-screen health bar such as "204/204". */
@Mod(HudHealthBarMod.MODID)
public class HudHealthBarMod {
    public static final String MODID = "hudhealthbar";

    public HudHealthBarMod() {
        HBConfig.load();
    }
}
